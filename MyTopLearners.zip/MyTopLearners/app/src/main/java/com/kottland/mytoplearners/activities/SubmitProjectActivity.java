package com.kottland.mytoplearners.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.kottland.mytoplearners.R;
import com.kottland.mytoplearners.model.learners;
import com.kottland.mytoplearners.services.RetrofitClient;
import com.kottland.mytoplearners.services.RetrofitClientRv;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SubmitProjectActivity extends AppCompatActivity {
    public static final String TAG = "SubmitProjectActivity";

    String firtNM, lastNM, emailAddresss, projectL;

    EditText firtName, lastName, emailAddres, projectLnk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit_project);

        firtName = (EditText) findViewById(R.id.firstName);
        lastName = (EditText) findViewById(R.id.lastName);
        emailAddres = (EditText) findViewById(R.id.emailAddress);
        projectLnk = (EditText) findViewById(R.id.projectLink);

    }

    public void submitProject(View view) {

        firtNM = firtName.getText().toString();
        lastNM = lastName.getText().toString();
        emailAddresss = emailAddres.getText().toString();
        projectL = projectLnk.getText().toString();

        if (firtNM.isEmpty()) {

            firtName.setError("Please Enter your first Name");
        } else if (lastNM.isEmpty()) {
            lastName.setError("Please Enter your Last Name");
        } else if (emailAddresss.isEmpty()) {
            emailAddres.setError("Please Enter your Email Address ");
        } else if (projectL.isEmpty()) {
            projectLnk.setError("Please Enter the Project URL");
        } else {
            validatQuestDialog();

        }


    }

    private void submitProjectPOST() {

        final ProgressDialog progressDialog = new ProgressDialog(SubmitProjectActivity.this);
        progressDialog.setMessage("Getting Submitting Project ...");
        progressDialog.show();


        Call<JsonElement> call = RetrofitClientRv.post().submitProject(emailAddresss, firtNM, lastNM, projectL);
        call.enqueue(new Callback<JsonElement>() {
            @Override
            public void onResponse(Call<JsonElement> call, Response<JsonElement> response) {

                Log.e( "Response Code -->", String.valueOf(response.code()));
                Log.e( "Response Succss -->", String.valueOf(response.isSuccessful()));
                Log.e( "Response Message -->", response.message());

                if (response.isSuccessful()) {

                    JSONObject jsonResponse = null;

                    try {
                        jsonResponse = new JSONObject(new Gson().toJson(response.body()));

                        Log.e("Response -->", jsonResponse.toString() );
                        String status = jsonResponse.getString("Status");
                        if (status.equals("success")|| status.equals("01")|| status.equals("1")
                        || status.equals("ok")){

                            MessageDialog("01");
                        }else {
                            MessageDialog("100");
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    /*
                    rowListItem = response.body();

                    Collections.reverse(rowListItem);*/
                    progressDialog.dismiss();


                } else {
                    progressDialog.dismiss();

                    Log.e(TAG, " Response Error " + String.valueOf(response.code()));
                }

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<JsonElement> call, Throwable t) {
                progressDialog.dismiss();

                Log.e(TAG, " Response Error " + t.getMessage());
            }
        });

    }


    public void validatQuestDialog() {

        final Dialog dialog_alert = new Dialog(SubmitProjectActivity.this);
        dialog_alert.setContentView(R.layout.question_dialog);
        dialog_alert.setCanceledOnTouchOutside(false);
        dialog_alert.setCancelable(false);

        final Button btnValidate = (Button) dialog_alert.findViewById(R.id.btn_validate);
        final ImageView ImgCancel = (ImageView) dialog_alert.findViewById(R.id.img);
        final TextView heardertxt = (TextView) dialog_alert.findViewById(R.id.txtheader);

        btnValidate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog_alert.dismiss();

                submitProjectPOST();


            }
        });
        ImgCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog_alert.dismiss();

            }
        });

        dialog_alert.show();
        //dialog_alert.setCanceledOnTouchOutside(false);
        Window window = dialog_alert.getWindow();
       // window.getAttributes().windowAnimations = R.style.DialogAnimation;

    }

    public void MessageDialog(String status) {

        final Dialog dialog_alert = new Dialog(SubmitProjectActivity.this);
        dialog_alert.setContentView(R.layout.success_dialog);
        dialog_alert.setCanceledOnTouchOutside(false);
        dialog_alert.setCancelable(true);

         ImageView statusImage = (ImageView) dialog_alert.findViewById(R.id.img);
         TextView statusMessage = (TextView) dialog_alert.findViewById(R.id.txtheader);

         if (status.equals("01")){
             statusImage.setImageResource(R.drawable.success_image);
             statusMessage.setText("Submission Successful");
         }else {
             statusImage.setImageResource(R.drawable.ic_icon_warn);
             statusMessage.setText("Submission not Successful");
         }


        dialog_alert.show();
        Window window = dialog_alert.getWindow();

    }



}
