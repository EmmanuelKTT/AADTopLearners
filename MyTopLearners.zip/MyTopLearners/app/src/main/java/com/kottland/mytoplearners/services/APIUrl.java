package com.kottland.mytoplearners.services;

public class APIUrl {

    public static final String BASEURL = "https://gadsapi.herokuapp.com/";

    public  static  final String SubMIT_URL = "https://docs.google.com/forms/d/e/";
}
