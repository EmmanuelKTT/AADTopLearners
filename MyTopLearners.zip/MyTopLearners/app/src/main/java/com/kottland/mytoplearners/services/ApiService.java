package com.kottland.mytoplearners.services;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.kottland.mytoplearners.model.learners;
import com.kottland.mytoplearners.model.skilliq;


import java.util.List;
import java.util.Map;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.PartMap;
import retrofit2.http.Path;
import retrofit2.http.Query;


public interface ApiService {


    @GET("/api/hours")
    Call<List<learners>> getTopLearners();

    @GET("/api/skilliq")
    Call<List<skilliq>> getTopSkillIq();


    @FormUrlEncoded
    @POST("1FAIpQLSf9d1TcNU6zc6KR8bSEM41Z1g1zl35cwZr2xyjIhaMAz8WChQ/formResponse")
    Call<JsonElement> submitProject(@Field("entry.1824927963") String email,
                            @Field("entry.1877115667") String name,
                            @Field("entry.2006916086") String lastName,
                            @Field(" entry.284483984") String projectlink);



}

