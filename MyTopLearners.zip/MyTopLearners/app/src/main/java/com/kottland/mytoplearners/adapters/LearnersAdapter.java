package com.kottland.mytoplearners.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.kottland.mytoplearners.R;
import com.kottland.mytoplearners.model.learners;

import java.util.ArrayList;
import java.util.List;


public class LearnersAdapter extends RecyclerView.Adapter<LearnersAdapter.ItemViewHolder> {
    private static List<learners> dataList;
    private LayoutInflater mInflater;
    private Context context;
    private boolean statusx = false;
    private int selectedPosition = -1;


    private int checkedPosition = 0;

    public LearnersAdapter(Context ctx, List<learners> data) {
        context = ctx;
        dataList = data;
        mInflater = LayoutInflater.from(context);
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {
        private ImageView imgProduct;
        // private CardView buttonMinus,buttonPlus;
        private TextView  name,  country;
        public LinearLayout linear_body;


        public ItemViewHolder(View itemView) {
            super(itemView);

            linear_body = (LinearLayout) itemView.findViewById(R.id.linear_body);
          name = (TextView) itemView.findViewById(R.id.name);
            country = (TextView) itemView.findViewById(R.id.country);
            imgProduct = (ImageView) itemView.findViewById(R.id.img);


        }

    }



    @Override
    public ItemViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.ln_row_items, parent, false);
        ItemViewHolder itemViewHolder = new ItemViewHolder(view);
        return itemViewHolder;
    }

    @Override
    public void onBindViewHolder(final ItemViewHolder holder, final int position) {
        Glide.with(context)
                .load(dataList.get(position).getBadgeUrl())
                .thumbnail(0.01f)
                .centerCrop()
                .into(holder.imgProduct);

        holder.name.setText(dataList.get(position).getName());
        holder.country.setText(dataList.get(position).getHours() + " learning hours,"+ " " +dataList.get(position).getCountry());


    }

    private void itemCheckChanged(View v) {
        selectedPosition = (Integer) v.getTag();
        notifyDataSetChanged();
    }




    @Override
    public int getItemCount() {
        return dataList.size();
    }

    private void onItemDismiss(int position) {
        dataList.remove(position);
        notifyItemRemoved(position);
    }


}