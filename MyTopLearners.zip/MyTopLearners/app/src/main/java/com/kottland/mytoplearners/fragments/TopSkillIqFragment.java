package com.kottland.mytoplearners.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.kottland.mytoplearners.R;
import com.kottland.mytoplearners.adapters.LearnersAdapter;
import com.kottland.mytoplearners.adapters.SkillIqAdapter;
import com.kottland.mytoplearners.model.learners;
import com.kottland.mytoplearners.model.skilliq;
import com.kottland.mytoplearners.services.RetrofitClient;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class TopSkillIqFragment extends Fragment {

    SkillIqAdapter rcAdapter;
    private List<skilliq> rowListItem = new ArrayList<>();
    private RecyclerView rView;
    public static final String TAG = "TopSkillIqFragment";
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;


    public static TopSkillIqFragment newInstance() {
        return new TopSkillIqFragment();
    }


    public TopSkillIqFragment() {
        // Required empty public constructor
    }
    public static TopSkillIqFragment newInstance(String param1, String param2) {
        TopSkillIqFragment fragment = new TopSkillIqFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
            // pageViewModel = ViewModelProviders.of(this).get(PageViewModel.class);
            //  pageViewModel.setIndex(TAG);
        }



    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_top_skill_iq, container, false);

        rowListItem = new ArrayList<>();

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);

        rView = (RecyclerView)root.findViewById(R.id.recyclerView);
        rView.setHasFixedSize(false);
        rView.setLayoutManager(layoutManager);
        rView.setNestedScrollingEnabled(false);

        getsKillIQData();

        return root;
    }


    private void getsKillIQData (){

        final ProgressDialog progressDialog = new ProgressDialog(getActivity());
        progressDialog.setMessage("Getting List of SkillIq ...");
        progressDialog.show();



        Call<List<skilliq>> call = RetrofitClient.get().getTopSkillIq();
        call.enqueue(new Callback<List<skilliq>>() {
            @Override
            public void onResponse(Call<List<skilliq>> call, Response<List<skilliq>> response) {

                if (response.isSuccessful()) {

                    rowListItem = response.body();

                    Collections.reverse(rowListItem);
                    progressDialog.dismiss();

                    loadRecyclerList();

                } else {
                    progressDialog.dismiss();

                    Log.e(TAG, " Response Error " + String.valueOf(response.code()));
                }

                progressDialog.dismiss();

            }

            @Override
            public void onFailure(Call<List<skilliq>> call, Throwable t) {
                progressDialog.dismiss();

                Log.e(TAG," Response Error "+t.getMessage());
            }
        });
    }


    private void loadRecyclerList() {

        rcAdapter = new SkillIqAdapter(getActivity(), rowListItem);
        rView.setAdapter(rcAdapter);

    }
}
